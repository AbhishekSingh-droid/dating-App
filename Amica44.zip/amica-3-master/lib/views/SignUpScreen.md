#SignUpScreen

Use the SignUpScreen template with basic widgets and validations. You can also customize it. And you can use the below snippet to navigate to the login screen from any action.

````
Navigator.of(context).push(MaterialPageRoute(
                        builder: (BuildContext context) => SignUpScreen()));
````
